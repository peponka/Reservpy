import type { Config } from 'tailwindcss'

const config: Config = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        orange: {
          primary: '#FF5C1F',
          hover:   '#E04A0F',
          light:   '#FFF3EC',
          lighter: '#FFF8F3',
          border:  '#F1E8E0',
        },
        brand: {
          text:    '#0F0F10',
          sub:     '#6B7280',
          muted:   '#9CA3AF',
        },
      },
      fontFamily: {
        sans: ['var(--font-inter)', 'Inter', 'system-ui', 'sans-serif'],
      },
      boxShadow: {
        card:  '0 2px 8px rgba(255,92,31,0.06), 0 8px 32px rgba(0,0,0,0.06)',
        'card-hover': '0 4px 16px rgba(255,92,31,0.12), 0 16px 48px rgba(0,0,0,0.09)',
        orange: '0 6px 24px rgba(255,92,31,0.28)',
      },
      animation: {
        'float': 'float 3s ease-in-out infinite',
      },
      keyframes: {
        float: {
          '0%,100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(-6px)' },
        },
      },
    },
  },
  plugins: [],
}
export default config
