'use client'
import { useState, useEffect } from 'react'
import { Calendar, Menu, X } from 'lucide-react'

const links = [
  { href: '#funciones', label: 'Funciones' },
  { href: '#como-funciona', label: 'Cómo funciona' },
  { href: '#testimonios', label: 'Testimonios' },
  { href: '#precios', label: 'Precios' },
]

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [open, setOpen] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12)
    window.addEventListener('scroll', onScroll)
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  return (
    <header
      className={`fixed top-0 inset-x-0 z-50 transition-all duration-300 ${
        scrolled ? 'bg-white/90 backdrop-blur-lg shadow-sm border-b border-orange-border' : 'bg-transparent'
      }`}
    >
      <nav className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between" aria-label="Navegación principal">
        {/* Logo */}
        <a href="#" className="flex items-center gap-2 font-bold text-lg text-brand-text" aria-label="Reservly Paraguay">
          <span className="w-8 h-8 rounded-lg bg-orange-primary flex items-center justify-center flex-shrink-0">
            <Calendar className="w-4 h-4 text-white" aria-hidden="true" />
          </span>
          Reservly
          <span className="text-orange-primary">Paraguay</span>
        </a>

        {/* Desktop links */}
        <ul className="hidden md:flex items-center gap-8" role="list">
          {links.map(l => (
            <li key={l.href}>
              <a
                href={l.href}
                className="text-sm font-medium text-brand-sub hover:text-brand-text transition-colors"
              >
                {l.label}
              </a>
            </li>
          ))}
        </ul>

        {/* Desktop CTAs */}
        <div className="hidden md:flex items-center gap-3">
          <a
            href="#"
            className="text-sm font-medium text-brand-sub hover:text-brand-text px-4 py-2 rounded-full transition-colors"
          >
            Ingresar
          </a>
          <a
            href="#"
            className="text-sm font-semibold bg-orange-primary hover:bg-orange-hover text-white px-5 py-2 rounded-full transition-all hover:shadow-orange"
            aria-label="Registrarse en Reservly"
          >
            Registrarse →
          </a>
        </div>

        {/* Mobile hamburger */}
        <button
          className="md:hidden p-2 rounded-lg text-brand-sub hover:bg-gray-100 transition-colors"
          onClick={() => setOpen(!open)}
          aria-expanded={open}
          aria-label={open ? 'Cerrar menú' : 'Abrir menú'}
        >
          {open ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </nav>

      {/* Mobile menu */}
      {open && (
        <div className="md:hidden bg-white border-t border-orange-border px-4 py-4 flex flex-col gap-3">
          {links.map(l => (
            <a
              key={l.href}
              href={l.href}
              className="py-2 text-sm font-medium text-brand-sub"
              onClick={() => setOpen(false)}
            >
              {l.label}
            </a>
          ))}
          <div className="pt-2 flex flex-col gap-2">
            <a href="#" className="text-center text-sm font-medium border border-orange-border rounded-full py-2.5 text-brand-text">
              Ingresar
            </a>
            <a href="#" className="text-center text-sm font-semibold bg-orange-primary text-white rounded-full py-2.5">
              Registrarse →
            </a>
          </div>
        </div>
      )}
    </header>
  )
}
