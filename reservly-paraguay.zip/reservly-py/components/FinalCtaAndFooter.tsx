'use client'
import { FadeIn } from './ui/FadeIn'
import { Building2, Users } from 'lucide-react'

export function FinalCta() {
  return (
    <section className="py-24 px-4 sm:px-6 bg-gradient-to-br from-orange-primary to-orange-hover text-center relative overflow-hidden">
      {/* Decorative circles */}
      <div className="absolute -top-24 -right-24 w-64 h-64 rounded-full bg-white/5 pointer-events-none" aria-hidden="true" />
      <div className="absolute -bottom-16 -left-16 w-48 h-48 rounded-full bg-white/5 pointer-events-none" aria-hidden="true" />

      <div className="max-w-2xl mx-auto relative">
        <FadeIn>
          <h2 className="text-3xl sm:text-4xl font-bold text-white tracking-tight mb-4">
            Empezá a recibir reservas hoy
          </h2>
          <p className="text-orange-100 text-lg mb-8">
            Creá tu cuenta en 5 minutos y compartí tu link. Tus clientes hacen el resto.
          </p>
          <div className="flex flex-wrap gap-3 justify-center">
            <a
              href="#"
              className="inline-flex items-center gap-2 bg-white text-orange-primary hover:bg-orange-lighter font-semibold px-7 py-3.5 rounded-full transition-all hover:-translate-y-0.5 shadow-lg"
            >
              <Building2 className="w-4 h-4" aria-hidden="true" />
              Crear mi negocio gratis
            </a>
            <a
              href="#"
              className="inline-flex items-center gap-2 border-2 border-white/50 hover:border-white text-white font-semibold px-7 py-3.5 rounded-full transition-colors"
            >
              <Users className="w-4 h-4" aria-hidden="true" />
              Quiero reservar turnos
            </a>
          </div>
        </FadeIn>
      </div>
    </section>
  )
}

const footerLinks = {
  Producto: [
    { label: 'Funciones', href: '#funciones' },
    { label: 'Cómo funciona', href: '#como-funciona' },
    { label: 'Precios', href: '#precios' },
    { label: 'Reservbot', href: '#reservbot' },
  ],
  Empresa: [
    { label: 'Sobre nosotros', href: '#' },
    { label: 'Blog', href: '#' },
    { label: 'Contacto', href: '#' },
  ],
  Legal: [
    { label: 'Términos', href: '#' },
    { label: 'Privacidad', href: '#' },
  ],
}

export function Footer() {
  return (
    <footer className="bg-brand-text text-white py-14 px-4 sm:px-6">
      <div className="max-w-5xl mx-auto">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-10 mb-12">
          <div className="col-span-1">
            <a href="#" className="flex items-center gap-2 font-bold text-lg mb-3" aria-label="Reservly Paraguay">
              <span className="w-8 h-8 rounded-lg bg-orange-primary flex items-center justify-center flex-shrink-0">
                <svg className="w-4 h-4 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" aria-hidden="true">
                  <rect x="3" y="4" width="18" height="18" rx="2"/><path d="M16 2v4M8 2v4M3 10h18"/>
                </svg>
              </span>
              Reservly
            </a>
            <p className="text-sm text-gray-400 leading-relaxed max-w-[220px]">
              El sistema de turnos online más simple para profesionales y negocios en Paraguay.
            </p>
          </div>

          {Object.entries(footerLinks).map(([section, links]) => (
            <div key={section}>
              <h3 className="text-xs font-bold uppercase tracking-widest text-gray-500 mb-4">{section}</h3>
              <ul className="flex flex-col gap-2.5" role="list">
                {links.map(l => (
                  <li key={l.label}>
                    <a href={l.href} className="text-sm text-gray-400 hover:text-white transition-colors">
                      {l.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="border-t border-white/10 pt-6 flex flex-wrap justify-between items-center gap-4 text-xs text-gray-500">
          <p>© 2026 Reservly Paraguay · Todos los derechos reservados</p>
          <p>Hecho con ❤️ para emprendedores paraguayos</p>
        </div>
      </div>
    </footer>
  )
}
