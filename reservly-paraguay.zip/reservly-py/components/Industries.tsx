'use client'
import { FadeIn, FadeInStagger, staggerItem } from './ui/FadeIn'
import { motion } from 'framer-motion'

const rubros = [
  { emoji: '✂️', label: 'Peluquerías' },
  { emoji: '🧠', label: 'Psicólogos' },
  { emoji: '💆', label: 'Estética' },
  { emoji: '🥗', label: 'Nutricionistas' },
  { emoji: '💪', label: 'Entrenadores' },
  { emoji: '🦷', label: 'Odontólogos' },
  { emoji: '💅', label: 'Manicuristas' },
  { emoji: '🩺', label: 'Kinesiólogos' },
]

export default function Industries() {
  return (
    <section className="py-16 px-4 sm:px-6 bg-white border-y border-orange-border">
      <div className="max-w-5xl mx-auto">
        <FadeIn>
          <p className="text-center text-sm font-semibold text-brand-sub uppercase tracking-widest mb-8">
            Ideal para profesionales y negocios de todos los rubros
          </p>
        </FadeIn>
        <FadeInStagger className="grid grid-cols-4 sm:grid-cols-8 gap-4">
          {rubros.map(r => (
            <motion.div
              key={r.label}
              variants={staggerItem}
              className="flex flex-col items-center gap-2 group"
            >
              <span className="w-14 h-14 rounded-2xl bg-orange-lighter border border-orange-border flex items-center justify-center text-2xl transition-all group-hover:bg-orange-light group-hover:border-orange-primary group-hover:shadow-card group-hover:-translate-y-1">
                {r.emoji}
              </span>
              <span className="text-xs text-brand-sub font-medium text-center leading-tight">{r.label}</span>
            </motion.div>
          ))}
        </FadeInStagger>
      </div>
    </section>
  )
}
