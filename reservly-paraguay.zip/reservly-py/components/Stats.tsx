'use client'
import { FadeInStagger, staggerItem } from './ui/FadeIn'
import { motion } from 'framer-motion'

const stats = [
  { num: '500+',   desc: 'Turnos gestionados' },
  { num: '24/7',   desc: 'Reservas abiertas' },
  { num: '5 min',  desc: 'Para configurar' },
  { num: '100%',   desc: 'Gratis para empezar' },
]

export default function Stats() {
  return (
    <section className="py-16 px-4 sm:px-6 bg-orange-primary" aria-label="Estadísticas de Reservly">
      <div className="max-w-5xl mx-auto">
        <FadeInStagger className="grid grid-cols-2 sm:grid-cols-4 gap-6 sm:gap-8 text-center">
          {stats.map(s => (
            <motion.div key={s.desc} variants={staggerItem}>
              <p className="text-4xl sm:text-5xl font-bold text-white mb-1">{s.num}</p>
              <p className="text-sm font-medium text-orange-100">{s.desc}</p>
            </motion.div>
          ))}
        </FadeInStagger>
      </div>
    </section>
  )
}
