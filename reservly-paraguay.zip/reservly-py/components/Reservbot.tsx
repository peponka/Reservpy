'use client'
import { useState } from 'react'
import { FadeIn } from './ui/FadeIn'
import { Bot, Send, Check, Calendar, Users, Clock, AlertCircle } from 'lucide-react'

const bullets = [
  { icon: Calendar, text: 'Agenda del día' },
  { icon: Users,    text: 'Turnos por empleado' },
  { icon: Clock,    text: 'Pendientes y huecos' },
  { icon: AlertCircle, text: 'Acciones con confirmación' },
]

const botReplies: Record<string, string> = {
  default: 'Hoy tenés 4 turnos: 10:00 Corte, 12:00 Consulta, 15:00 Tratamiento y 17:30 Color. Hay un hueco libre a las 13:30.',
  cancel: '⚠️ Necesito tu confirmación antes de cancelar el turno de Martina a las 15:00 hs.',
  confirm: '✅ Listo. El turno de Martina fue cancelado. ¿Querés que le envíe una notificación?',
}

type Msg = { from: 'user' | 'bot'; text: string; isConfirm?: boolean }

const initialMsgs: Msg[] = [
  { from: 'user', text: '¿Qué turnos tengo hoy?' },
  { from: 'bot', text: botReplies.default },
  { from: 'user', text: 'Cancelame el de las 15:00.' },
  { from: 'bot', text: botReplies.cancel, isConfirm: true },
]

export default function Reservbot() {
  const [msgs, setMsgs] = useState<Msg[]>(initialMsgs)
  const [input, setInput] = useState('')
  const [confirmed, setConfirmed] = useState(false)

  const handleSend = () => {
    if (!input.trim()) return
    const userMsg: Msg = { from: 'user', text: input.trim() }
    const botMsg: Msg = { from: 'bot', text: botReplies.default }
    setMsgs(prev => [...prev, userMsg, botMsg])
    setInput('')
  }

  const handleConfirm = () => {
    setConfirmed(true)
    setMsgs(prev => [...prev, { from: 'bot', text: botReplies.confirm }])
  }

  return (
    <section className="py-24 px-4 sm:px-6 bg-orange-lighter border-y border-orange-border">
      <div className="max-w-5xl mx-auto">
        <div className="grid lg:grid-cols-2 gap-12 items-center">

          {/* Left: Text */}
          <FadeIn direction="left">
            <span className="inline-block text-xs font-bold uppercase tracking-widest bg-orange-primary text-white px-3 py-1 rounded-full mb-4">
              Nuevo en Pro
            </span>
            <h2 className="text-3xl sm:text-4xl font-bold text-brand-text tracking-tight mb-4 leading-tight">
              Reservbot entiende tu agenda y te ayuda a operar más rápido
            </h2>
            <p className="text-brand-sub text-base mb-6 leading-relaxed">
              El asistente interno de Reservly responde preguntas del negocio, resume turnos por empleado y prepara acciones como cancelar o reprogramar, siempre con confirmación antes de tocar datos sensibles.
            </p>
            <ul className="flex flex-col gap-3 mb-8" role="list">
              {bullets.map(b => (
                <li key={b.text} className="flex items-center gap-3">
                  <span className="w-8 h-8 rounded-lg bg-orange-light border border-orange-border flex items-center justify-center flex-shrink-0">
                    <b.icon className="w-4 h-4 text-orange-primary" aria-hidden="true" />
                  </span>
                  <span className="text-sm font-medium text-brand-text">{b.text}</span>
                </li>
              ))}
            </ul>
            <div className="flex flex-wrap gap-3">
              <a href="#" className="bg-orange-primary hover:bg-orange-hover text-white font-semibold px-5 py-2.5 rounded-full transition-all hover:shadow-orange text-sm">
                Probar Reservly
              </a>
              <a href="#precios" className="border-2 border-orange-border hover:border-orange-primary text-brand-text font-semibold px-5 py-2.5 rounded-full transition-colors text-sm">
                Ver plan Pro
              </a>
            </div>
          </FadeIn>

          {/* Right: Chat mockup */}
          <FadeIn direction="right">
            <div className="bg-white rounded-2xl border border-orange-border shadow-card-hover overflow-hidden">
              {/* Chat header */}
              <div className="px-4 py-3 border-b border-orange-border flex items-center gap-3 bg-orange-lighter">
                <div className="w-8 h-8 rounded-full bg-orange-primary flex items-center justify-center flex-shrink-0">
                  <Bot className="w-4 h-4 text-white" aria-hidden="true" />
                </div>
                <div>
                  <p className="text-sm font-bold text-brand-text">Reservbot</p>
                  <p className="text-xs text-green-600 font-medium">● Asistente Pro</p>
                </div>
              </div>

              {/* Messages */}
              <div className="p-4 flex flex-col gap-3 min-h-[280px] max-h-80 overflow-y-auto" role="log" aria-label="Conversación con Reservbot">
                {msgs.map((m, i) => (
                  <div key={i} className={`flex ${m.from === 'user' ? 'justify-end' : 'justify-start'}`}>
                    <div className={`max-w-[80%] px-3.5 py-2.5 rounded-2xl text-sm leading-snug ${
                      m.from === 'user'
                        ? 'bg-orange-primary text-white rounded-br-md'
                        : 'bg-orange-lighter border border-orange-border text-brand-text rounded-bl-md'
                    }`}>
                      {m.text}
                      {m.isConfirm && !confirmed && (
                        <div className="mt-2.5 flex gap-2">
                          <button
                            onClick={handleConfirm}
                            className="flex items-center gap-1 bg-orange-primary text-white text-xs font-semibold px-3 py-1.5 rounded-full hover:bg-orange-hover transition-colors"
                          >
                            <Check className="w-3 h-3" /> Confirmar
                          </button>
                          <button className="bg-white border border-orange-border text-brand-sub text-xs font-medium px-3 py-1.5 rounded-full hover:bg-gray-50 transition-colors">
                            Cancelar
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>

              {/* Input */}
              <div className="px-4 py-3 border-t border-orange-border flex gap-2">
                <input
                  type="text"
                  value={input}
                  onChange={e => setInput(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && handleSend()}
                  placeholder="Preguntale a Reservbot..."
                  className="flex-1 text-sm bg-orange-lighter border border-orange-border rounded-full px-4 py-2 outline-none focus:ring-2 focus:ring-orange-primary/30 focus:border-orange-primary transition-all"
                  aria-label="Mensaje para Reservbot"
                />
                <button
                  onClick={handleSend}
                  className="w-9 h-9 rounded-full bg-orange-primary hover:bg-orange-hover flex items-center justify-center flex-shrink-0 transition-colors"
                  aria-label="Enviar mensaje"
                >
                  <Send className="w-4 h-4 text-white" aria-hidden="true" />
                </button>
              </div>
            </div>
          </FadeIn>
        </div>
      </div>
    </section>
  )
}
