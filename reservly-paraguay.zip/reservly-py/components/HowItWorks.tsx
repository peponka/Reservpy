'use client'
import { FadeIn, FadeInStagger, staggerItem } from './ui/FadeIn'
import { motion } from 'framer-motion'
import { UserPlus, Link2, LayoutDashboard } from 'lucide-react'

const steps = [
  {
    num: '01',
    icon: UserPlus,
    title: 'Creás tu cuenta',
    desc: 'Registrate en segundos. Cargá tus servicios, horarios de atención y listo. Sin código, sin configuraciones técnicas.',
  },
  {
    num: '02',
    icon: Link2,
    title: 'Compartís el link',
    desc: 'Tus clientes entran a tu página personalizada, eligen servicio, fecha y hora. Sin apps ni complicaciones.',
  },
  {
    num: '03',
    icon: LayoutDashboard,
    title: 'Gestionás todo',
    desc: 'Ves y controlás tus turnos desde el panel. Confirmá, cancelá, dejá notas y analizá métricas de tu negocio.',
  },
]

export default function HowItWorks() {
  return (
    <section id="como-funciona" className="py-24 px-4 sm:px-6 bg-orange-lighter border-t border-orange-border">
      <div className="max-w-5xl mx-auto">
        <FadeIn className="text-center mb-14">
          <span className="inline-block text-xs font-bold uppercase tracking-widest text-orange-primary mb-3">
            Cómo funciona
          </span>
          <h2 className="text-3xl sm:text-4xl font-bold text-brand-text tracking-tight mb-4">
            Tres pasos y ya estás recibiendo reservas
          </h2>
          <p className="text-brand-sub text-lg">Configurá tu cuenta y empezá a recibir turnos hoy mismo</p>
        </FadeIn>

        <FadeInStagger className="grid sm:grid-cols-3 gap-6 mb-10">
          {steps.map((s, i) => (
            <motion.div
              key={s.num}
              variants={staggerItem}
              className="bg-white rounded-2xl border border-orange-border p-7 shadow-card hover:shadow-card-hover hover:-translate-y-1 transition-all relative"
            >
              <span className="absolute top-5 right-5 text-4xl font-black text-orange-border/80 select-none" aria-hidden="true">
                {s.num}
              </span>
              <div className="w-12 h-12 rounded-xl bg-orange-light flex items-center justify-center mb-5">
                <s.icon className="w-6 h-6 text-orange-primary" aria-hidden="true" />
              </div>
              <h3 className="font-bold text-xl text-brand-text mb-2">{s.title}</h3>
              <p className="text-brand-sub text-sm leading-relaxed">{s.desc}</p>
            </motion.div>
          ))}
        </FadeInStagger>

        <FadeIn className="text-center">
          <a
            href="#"
            className="inline-flex items-center gap-2 bg-orange-primary hover:bg-orange-hover text-white font-semibold px-8 py-3.5 rounded-full transition-all hover:shadow-orange hover:-translate-y-0.5"
          >
            Empezar ahora — es gratis
          </a>
        </FadeIn>
      </div>
    </section>
  )
}
