'use client'
import { FadeIn, FadeInStagger, staggerItem } from './ui/FadeIn'
import { motion } from 'framer-motion'
import { Check, X, CreditCard } from 'lucide-react'

type PlanFeature = { text: string; included: boolean }

const freePlan: PlanFeature[] = [
  { text: '1 miembro del equipo', included: true },
  { text: 'Hasta 10 reservas/mes', included: true },
  { text: 'Página pública de reservas', included: true },
  { text: 'Gestión de servicios', included: true },
  { text: 'Recordatorios automáticos', included: true },
  { text: 'Reportes avanzados', included: false },
  { text: 'Reservbot incluido', included: false },
  { text: 'Soporte prioritario', included: false },
]

const proPlan: PlanFeature[] = [
  { text: 'Equipo ilimitado', included: true },
  { text: 'Reservas ilimitadas', included: true },
  { text: 'Página pública de reservas', included: true },
  { text: 'Emails de confirmación', included: true },
  { text: 'Reservbot incluido', included: true },
  { text: 'Recordatorios 24hs automáticos', included: true },
  { text: 'Reportes avanzados', included: true },
  { text: 'Soporte prioritario', included: true },
]

function Feature({ f }: { f: PlanFeature }) {
  return (
    <li className="flex items-start gap-2.5 text-sm">
      {f.included
        ? <Check className="w-4 h-4 text-green-500 flex-shrink-0 mt-0.5" aria-hidden="true" />
        : <X className="w-4 h-4 text-gray-300 flex-shrink-0 mt-0.5" aria-hidden="true" />
      }
      <span className={f.included ? 'text-brand-text' : 'text-brand-muted'}>{f.text}</span>
    </li>
  )
}

export default function Pricing() {
  return (
    <section id="precios" className="py-24 px-4 sm:px-6 bg-orange-lighter border-t border-orange-border">
      <div className="max-w-5xl mx-auto">
        <FadeIn className="text-center mb-14">
          <span className="inline-block text-xs font-bold uppercase tracking-widest text-orange-primary mb-3">
            Planes y precios
          </span>
          <h2 className="text-3xl sm:text-4xl font-bold text-brand-text tracking-tight mb-4">
            Empezá gratis y escalá cuando lo necesités
          </h2>
          <p className="text-brand-sub text-lg">Sin contratos, sin sorpresas. Cancelá cuando quieras.</p>
        </FadeIn>

        <FadeInStagger className="grid sm:grid-cols-2 gap-5 max-w-3xl mx-auto">

          {/* Free */}
          <motion.div
            variants={staggerItem}
            className="bg-white rounded-2xl border border-orange-border p-8 shadow-card flex flex-col"
          >
            <p className="text-xs font-bold uppercase tracking-widest text-brand-sub mb-4">Free</p>
            <div className="flex items-baseline gap-1 mb-1">
              <span className="text-4xl font-bold text-brand-text">Gratis</span>
            </div>
            <p className="text-sm text-brand-sub mb-6">Para siempre · Sin vencimiento</p>
            <ul className="flex flex-col gap-3 mb-8 flex-1" role="list" aria-label="Funciones del plan Free">
              {freePlan.map(f => <Feature key={f.text} f={f} />)}
            </ul>
            <a
              href="#"
              className="w-full text-center py-3 rounded-full border-2 border-orange-border hover:border-orange-primary text-brand-text font-semibold transition-colors text-sm"
            >
              Empezar gratis
            </a>
          </motion.div>

          {/* Pro */}
          <motion.div
            variants={staggerItem}
            className="bg-white rounded-2xl border-2 border-orange-primary p-8 shadow-card-hover flex flex-col relative"
          >
            <span className="absolute -top-3.5 left-1/2 -translate-x-1/2 bg-orange-primary text-white text-xs font-bold px-4 py-1 rounded-full whitespace-nowrap">
              ⭐ Recomendado
            </span>
            <p className="text-xs font-bold uppercase tracking-widest text-orange-primary mb-4">Pro</p>
            <div className="flex items-baseline gap-1 mb-1">
              <span className="text-4xl font-bold text-brand-text">Gs. 99.000</span>
            </div>
            <p className="text-sm text-brand-sub mb-6">/mes · Sin tarjeta de crédito</p>
            <ul className="flex flex-col gap-3 mb-8 flex-1" role="list" aria-label="Funciones del plan Pro">
              {proPlan.map(f => <Feature key={f.text} f={f} />)}
            </ul>
            <a
              href="#"
              className="w-full text-center py-3 rounded-full bg-orange-primary hover:bg-orange-hover text-white font-semibold transition-all hover:shadow-orange text-sm"
            >
              Suscribirse →
            </a>
          </motion.div>
        </FadeInStagger>

        <FadeIn className="text-center mt-5">
          <p className="text-xs text-brand-muted flex items-center justify-center gap-1.5">
            <CreditCard className="w-3.5 h-3.5" aria-hidden="true" />
            Pagos procesados de forma segura por Bancard / Pagopar · Cancelá cuando quieras
          </p>
        </FadeIn>
      </div>
    </section>
  )
}
