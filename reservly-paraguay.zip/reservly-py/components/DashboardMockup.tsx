'use client'
import { motion } from 'framer-motion'
import { Bell, Check, TrendingUp, Users, Calendar, DollarSign } from 'lucide-react'

const avatarColors: Record<string, string> = {
  MG: 'bg-violet-100 text-violet-700',
  JL: 'bg-sky-100 text-sky-700',
  AM: 'bg-pink-100 text-pink-700',
}

const turnos = [
  { initials: 'MG', name: 'María González', time: '09:00', service: 'Corte y color', price: 'Gs. 85.000', status: 'Confirmado', statusColor: 'bg-green-50 text-green-700' },
  { initials: 'JL', name: 'Juan López',     time: '10:30', service: 'Consulta',       price: 'Gs. 60.000', status: 'Pendiente',  statusColor: 'bg-amber-50 text-amber-700' },
  { initials: 'AM', name: 'Ana Martínez',   time: '11:00', service: 'Tratamiento facial', price: 'Gs. 120.000', status: 'Confirmado', statusColor: 'bg-green-50 text-green-700' },
]

const stats = [
  { icon: DollarSign, label: 'Hoy',          value: 'Gs. 350.000', change: '+12%', changeColor: 'text-green-600' },
  { icon: Calendar,   label: 'Turnos hoy',   value: '8',           change: '3 confirmados', changeColor: 'text-brand-sub' },
  { icon: TrendingUp, label: 'Esta semana',  value: 'Gs. 2.450.000', change: '+8%', changeColor: 'text-green-600' },
  { icon: Users,      label: 'Clientes nuevos', value: '12',        change: 'Este mes', changeColor: 'text-brand-sub' },
]

export default function DashboardMockup() {
  return (
    <section className="px-4 sm:px-6 pb-20 bg-white">
      <div className="max-w-5xl mx-auto relative">

        {/* Floating badges */}
        <motion.div
          initial={{ opacity: 0, x: -30, y: 10 }}
          animate={{ opacity: 1, x: 0, y: 0 }}
          transition={{ delay: 0.6, duration: 0.5 }}
          className="absolute -left-4 top-16 z-10 hidden lg:flex items-center gap-2 bg-white rounded-2xl shadow-card px-4 py-2.5 border border-orange-border animate-float"
          style={{ animationDelay: '0s' }}
          aria-hidden="true"
        >
          <span className="w-8 h-8 rounded-full bg-orange-light flex items-center justify-center">
            <Bell className="w-4 h-4 text-orange-primary" />
          </span>
          <div>
            <p className="text-xs font-semibold text-brand-text">Nueva reserva</p>
            <p className="text-xs text-brand-sub">María García · 09:00 hs</p>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 30, y: 10 }}
          animate={{ opacity: 1, x: 0, y: 0 }}
          transition={{ delay: 0.75, duration: 0.5 }}
          className="absolute -right-4 top-28 z-10 hidden lg:flex items-center gap-2 bg-orange-primary rounded-2xl shadow-orange px-4 py-2.5 animate-float"
          style={{ animationDelay: '1.5s' }}
          aria-hidden="true"
        >
          <Check className="w-4 h-4 text-white flex-shrink-0" />
          <p className="text-sm font-semibold text-white">¡Confirmado!</p>
        </motion.div>

        {/* Browser mockup */}
        <motion.div
          initial={{ opacity: 0, y: 32 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4, duration: 0.65, ease: [0.22, 1, 0.36, 1] }}
          className="rounded-2xl overflow-hidden shadow-card-hover border border-orange-border"
        >
          {/* Browser bar */}
          <div className="bg-gray-50 border-b border-orange-border px-4 py-3 flex items-center gap-3">
            <div className="flex gap-1.5" aria-hidden="true">
              <span className="w-3 h-3 rounded-full bg-red-400" />
              <span className="w-3 h-3 rounded-full bg-amber-400" />
              <span className="w-3 h-3 rounded-full bg-green-400" />
            </div>
            <div className="flex-1 mx-4">
              <div className="bg-white border border-orange-border rounded-lg px-3 py-1 text-xs text-brand-sub text-center max-w-xs mx-auto">
                reservly.com.py/admin/dashboard
              </div>
            </div>
          </div>

          {/* Dashboard content */}
          <div className="bg-orange-lighter p-5 sm:p-6">
            <div className="max-w-2xl mx-auto">
              <div className="mb-5">
                <h2 className="text-lg font-bold text-brand-text">Hola, María 👋</h2>
                <p className="text-sm text-brand-sub">Así va tu día en tu negocio</p>
              </div>

              {/* KPI cards */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-5">
                {stats.map(s => (
                  <div key={s.label} className="bg-white rounded-xl p-3 border border-orange-border shadow-card">
                    <div className="flex items-center gap-1.5 mb-1.5">
                      <s.icon className="w-3.5 h-3.5 text-orange-primary" aria-hidden="true" />
                      <p className="text-xs text-brand-sub font-medium">{s.label}</p>
                    </div>
                    <p className="text-sm font-bold text-brand-text leading-tight">{s.value}</p>
                    <p className={`text-xs mt-0.5 font-medium ${s.changeColor}`}>{s.change}</p>
                  </div>
                ))}
              </div>

              {/* Appointments */}
              <div className="bg-white rounded-xl border border-orange-border shadow-card overflow-hidden">
                <div className="px-4 py-3 border-b border-orange-border flex items-center justify-between">
                  <p className="text-sm font-semibold text-brand-text">Próximos turnos</p>
                  <button className="text-xs text-orange-primary font-medium hover:underline">Ver todos</button>
                </div>
                <div className="divide-y divide-orange-border">
                  {turnos.map(t => (
                    <div key={t.initials} className="px-4 py-3 flex items-center gap-3">
                      <span className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 ${avatarColors[t.initials]}`}>
                        {t.initials}
                      </span>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-semibold text-brand-text truncate">{t.name}</p>
                        <p className="text-xs text-brand-sub">{t.time} · {t.service}</p>
                      </div>
                      <p className="text-sm font-semibold text-brand-text hidden sm:block">{t.price}</p>
                      <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${t.statusColor}`}>
                        {t.status}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  )
}
