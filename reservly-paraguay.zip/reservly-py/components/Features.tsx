'use client'
import { FadeIn, FadeInStagger, staggerItem } from './ui/FadeIn'
import { motion } from 'framer-motion'
import { Mail, Shield, BarChart2, Smartphone } from 'lucide-react'

const smallFeatures = [
  {
    icon: Mail,
    title: 'Emails automáticos',
    desc: 'Confirmaciones y recordatorios se envían solos, sin que vos tengas que hacer nada.',
  },
  {
    icon: Shield,
    title: 'Política de cancelación',
    desc: 'Definí horas de anticipación mínima para cambios. Tus reglas, tu negocio.',
  },
  {
    icon: BarChart2,
    title: 'Reportes y métricas',
    desc: 'Ingresos, servicios más populares y horarios pico para tomar mejores decisiones.',
  },
  {
    icon: Smartphone,
    title: '100% mobile',
    desc: 'Tus clientes reservan desde cualquier dispositivo. Sin apps, sin instalaciones.',
  },
]

export default function Features() {
  return (
    <section id="funciones" className="py-24 px-4 sm:px-6 bg-white">
      <div className="max-w-5xl mx-auto">

        {/* Header */}
        <FadeIn className="text-center mb-14">
          <span className="inline-block text-xs font-bold uppercase tracking-widest text-orange-primary mb-3">
            Funcionalidades
          </span>
          <h2 className="text-3xl sm:text-4xl font-bold text-brand-text tracking-tight mb-4">
            Todo lo que necesitás para estar organizado
          </h2>
          <p className="text-brand-sub text-lg max-w-xl mx-auto">
            Sin configuraciones complejas. Todo funciona de entrada, desde el primer día.
          </p>
        </FadeIn>

        {/* Big cards row */}
        <div className="grid sm:grid-cols-2 gap-5 mb-5">

          {/* Panel card */}
          <FadeIn direction="left">
            <div className="rounded-2xl bg-orange-lighter border border-orange-border p-7 h-full shadow-card hover:shadow-card-hover transition-shadow">
              <h3 className="font-bold text-xl text-brand-text mb-2">Panel de control centralizado</h3>
              <p className="text-brand-sub text-sm mb-6 leading-relaxed">
                Vista completa de tu día: turnos confirmados, pendientes, ingresos y clientes nuevos. Todo en un solo lugar.
              </p>
              <div className="flex gap-3">
                {[
                  { val: '8',         lbl: 'Hoy' },
                  { val: '34',        lbl: 'Semana' },
                  { val: 'Gs. 980k',  lbl: 'Ingresos' },
                ].map(s => (
                  <div key={s.lbl} className="flex-1 bg-white rounded-xl p-3 border border-orange-border text-center shadow-sm">
                    <p className="text-xl font-bold text-orange-primary">{s.val}</p>
                    <p className="text-xs text-brand-sub mt-0.5">{s.lbl}</p>
                  </div>
                ))}
              </div>
            </div>
          </FadeIn>

          {/* Team card */}
          <FadeIn direction="right">
            <div className="rounded-2xl bg-orange-lighter border border-orange-border p-7 h-full shadow-card hover:shadow-card-hover transition-shadow">
              <h3 className="font-bold text-xl text-brand-text mb-2">Trabajo en equipo</h3>
              <p className="text-brand-sub text-sm mb-6 leading-relaxed">
                Agregá empleados, asignales servicios y horarios propios. Tus clientes eligen con quién reservar.
              </p>
              <div className="flex flex-col gap-3">
                {[
                  { initials: 'SR', name: 'Sofía R.', role: 'Estilista', turnos: '5 turnos hoy', color: 'bg-violet-100 text-violet-700' },
                  { initials: 'MG', name: 'Martín G.', role: 'Barbero', turnos: '3 turnos hoy', color: 'bg-sky-100 text-sky-700' },
                ].map(e => (
                  <div key={e.initials} className="flex items-center gap-3 bg-white rounded-xl px-4 py-3 border border-orange-border shadow-sm">
                    <span className={`w-9 h-9 rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0 ${e.color}`}>
                      {e.initials}
                    </span>
                    <div className="flex-1">
                      <p className="text-sm font-semibold text-brand-text">{e.name} · {e.role}</p>
                    </div>
                    <span className="text-xs font-medium text-orange-primary bg-orange-light px-2.5 py-1 rounded-full">{e.turnos}</span>
                  </div>
                ))}
              </div>
            </div>
          </FadeIn>
        </div>

        {/* Small cards grid */}
        <FadeInStagger className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {smallFeatures.map(f => (
            <motion.div
              key={f.title}
              variants={staggerItem}
              className="bg-white rounded-2xl border border-orange-border p-5 shadow-card hover:shadow-card-hover hover:-translate-y-1 transition-all"
            >
              <div className="w-10 h-10 rounded-xl bg-orange-light flex items-center justify-center mb-4">
                <f.icon className="w-5 h-5 text-orange-primary" aria-hidden="true" />
              </div>
              <h3 className="font-bold text-brand-text mb-1.5">{f.title}</h3>
              <p className="text-sm text-brand-sub leading-relaxed">{f.desc}</p>
            </motion.div>
          ))}
        </FadeInStagger>
      </div>
    </section>
  )
}
