'use client'
import { FadeIn, FadeInStagger, staggerItem } from './ui/FadeIn'
import { motion } from 'framer-motion'

const testimonials = [
  {
    quote: 'Antes pasaba horas coordinando turnos por WhatsApp. Ahora mis pacientes reservan solos y yo solo confirmo. Un cambio enorme para mi consultorio en Asunción.',
    name: 'Sofía Rodríguez',
    role: 'Psicóloga · Asunción',
    initials: 'SR',
    color: 'bg-violet-100 text-violet-700',
  },
  {
    quote: 'La vista de calendario está buenísima. Veo todos mis turnos del día de un vistazo y puedo confirmar o cancelar al toque. Mis clientes también lo aman.',
    name: 'Martín González',
    role: 'Dueño de peluquería · Ciudad del Este',
    initials: 'MG',
    color: 'bg-sky-100 text-sky-700',
  },
  {
    quote: 'El historial de cada paciente me permite ver todos sus turnos y el seguimiento completo. Muy útil para pacientes crónicos. Además los pagos con Bancard funcionan perfecto.',
    name: 'Laura Martínez',
    role: 'Nutricionista · Encarnación',
    initials: 'LM',
    color: 'bg-pink-100 text-pink-700',
  },
]

export default function Testimonials() {
  return (
    <section id="testimonios" className="py-24 px-4 sm:px-6 bg-white border-t border-orange-border">
      <div className="max-w-5xl mx-auto">
        <FadeIn className="text-center mb-14">
          <span className="inline-block text-xs font-bold uppercase tracking-widest text-orange-primary mb-3">
            Testimonios
          </span>
          <h2 className="text-3xl sm:text-4xl font-bold text-brand-text tracking-tight mb-4">
            Lo que dicen nuestros usuarios
          </h2>
          <p className="text-brand-sub text-lg">Negocios reales que ya gestionan sus turnos con Reservly Paraguay</p>
        </FadeIn>

        <FadeInStagger className="grid sm:grid-cols-3 gap-6">
          {testimonials.map(t => (
            <motion.div
              key={t.name}
              variants={staggerItem}
              className="bg-white rounded-2xl border border-orange-border p-7 shadow-card hover:shadow-card-hover hover:-translate-y-1 transition-all flex flex-col"
            >
              <span className="text-5xl font-black text-orange-primary leading-none mb-4 select-none" aria-hidden="true">"</span>
              <p className="text-sm text-brand-sub leading-relaxed flex-1 mb-6">
                &ldquo;{t.quote}&rdquo;
              </p>
              <div className="flex items-center gap-3 pt-4 border-t border-orange-border">
                <span className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold flex-shrink-0 ${t.color}`}>
                  {t.initials}
                </span>
                <div>
                  <p className="text-sm font-bold text-brand-text">{t.name}</p>
                  <p className="text-xs text-brand-sub">{t.role}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </FadeInStagger>
      </div>
    </section>
  )
}
