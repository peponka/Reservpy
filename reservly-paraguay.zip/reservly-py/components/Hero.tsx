'use client'
import { motion } from 'framer-motion'
import { CheckCircle2, Building2, Play } from 'lucide-react'

const item = (delay: number) => ({
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.55, delay, ease: [0.22, 1, 0.36, 1] },
})

export default function Hero() {
  return (
    <section className="pt-28 pb-8 px-4 sm:px-6 bg-white text-center overflow-hidden">
      <div className="max-w-4xl mx-auto">

        {/* Badge */}
        <motion.div {...item(0)} className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-orange-light border border-orange-border text-orange-primary text-sm font-semibold mb-6">
          <span className="w-2 h-2 rounded-full bg-orange-primary animate-pulse" aria-hidden="true" />
          500+ turnos gestionados por negocios reales
        </motion.div>

        {/* Headline */}
        <motion.h1
          {...item(0.07)}
          className="text-4xl sm:text-5xl lg:text-[64px] font-bold leading-[1.1] tracking-tight text-brand-text mb-5"
        >
          Un sistema de turnos que<br className="hidden sm:block" />
          mantiene tu negocio{' '}
          <span className="text-orange-primary">en orden</span>
        </motion.h1>

        {/* Subheadline */}
        <motion.p {...item(0.14)} className="text-lg sm:text-xl text-brand-sub max-w-2xl mx-auto mb-8 leading-relaxed">
          Tus clientes reservan cuando quieran, vos controlás todo desde un panel simple. Sin llamadas, sin papel, sin complicaciones.
        </motion.p>

        {/* CTAs */}
        <motion.div {...item(0.21)} className="flex flex-wrap gap-3 justify-center mb-6">
          <a
            href="#"
            className="inline-flex items-center gap-2 bg-orange-primary hover:bg-orange-hover text-white font-semibold px-7 py-3.5 rounded-full transition-all hover:shadow-orange hover:-translate-y-0.5"
          >
            <Building2 className="w-4 h-4" aria-hidden="true" />
            Crear mi negocio gratis →
          </a>
          <a
            href="#como-funciona"
            className="inline-flex items-center gap-2 border-2 border-orange-border hover:border-orange-primary text-brand-text font-semibold px-7 py-3.5 rounded-full transition-all hover:bg-orange-lighter"
          >
            <Play className="w-4 h-4 fill-current text-orange-primary" aria-hidden="true" />
            Ver cómo funciona
          </a>
        </motion.div>

        {/* Trust badges */}
        <motion.div {...item(0.28)} className="flex flex-wrap justify-center gap-x-6 gap-y-2 text-sm text-brand-sub">
          {['Sin tarjeta de crédito', 'Configuración en 5 min', 'Cancelá cuando quieras'].map(t => (
            <span key={t} className="flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-green-500 flex-shrink-0" aria-hidden="true" />
              {t}
            </span>
          ))}
        </motion.div>
      </div>
    </section>
  )
}
