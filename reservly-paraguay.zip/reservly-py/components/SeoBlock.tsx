'use client'
import { FadeIn, FadeInStagger, staggerItem } from './ui/FadeIn'
import { motion } from 'framer-motion'

const blocks = [
  {
    title: '¿Qué es Reservly Paraguay?',
    text: 'Reservly Paraguay es un sistema de turnos online pensado para profesionales y pequeños negocios que atienden por cita en Paraguay. Peluquerías, psicólogos, nutricionistas, odontólogos, fisioterapeutas y muchos más usan Reservly para gestionar su agenda sin llamadas, sin mensajes de WhatsApp y sin papel. Tus clientes reservan directamente desde su celular las 24 horas del día, y vos recibís una notificación al instante.',
  },
  {
    title: 'Sistema de reservas online para tu negocio en Paraguay',
    text: 'Con Reservly creás tu perfil en minutos: configurás tus servicios, tus horarios de atención y generás tu link personalizado para compartir con tus clientes. Cada reserva dispara una confirmación automática. Vos podés confirmar, rechazar o cancelar turnos desde tu panel, sin depender de nadie. Es la solución de gestión de turnos más simple del mercado para profesionales independientes en Asunción, Ciudad del Este, Encarnación y todo el país.',
  },
  {
    title: 'Beneficios de digitalizar tu agenda en Paraguay',
    text: 'Digitalizar tu agenda online reduce el tiempo que perdés coordinando horarios y minimiza los turnos cancelados de último momento. Con una política de cancelación configurable, tus clientes solo pueden cancelar o reprogramar con la anticipación que vos definas. Empezá gratis con hasta 10 reservas online por mes, y pasá al plan Pro cuando lo necesités. Sin contratos, sin tarjeta de crédito, con pagos locales via Bancard o Pagopar.',
  },
]

export default function SeoBlock() {
  return (
    <section className="py-24 px-4 sm:px-6 bg-white border-t border-orange-border">
      <div className="max-w-5xl mx-auto">
        <FadeInStagger className="grid sm:grid-cols-3 gap-8">
          {blocks.map(b => (
            <motion.div key={b.title} variants={staggerItem}>
              <h2 className="text-lg font-bold text-brand-text mb-3 leading-snug">{b.title}</h2>
              <p className="text-sm text-brand-sub leading-relaxed">{b.text}</p>
            </motion.div>
          ))}
        </FadeInStagger>
      </div>
    </section>
  )
}
