'use client'
import { useState } from 'react'
import { FadeIn, FadeInStagger, staggerItem } from './ui/FadeIn'
import { motion, AnimatePresence } from 'framer-motion'
import { ChevronDown } from 'lucide-react'

const faqs = [
  {
    q: '¿Necesito conocimientos técnicos para configurar Reservly?',
    a: 'No. El proceso tarda menos de 5 minutos: creás tu cuenta, cargás tus servicios y horarios, y ya tenés tu link de reservas listo para compartir con tus clientes. Sin código, sin instalaciones.',
  },
  {
    q: '¿Mis clientes necesitan descargar alguna app?',
    a: 'No. Tus clientes reservan directamente desde el navegador de su celular o computadora. No necesitan registrarse ni instalar nada. Solo entran a tu link y listo.',
  },
  {
    q: '¿Qué pasa cuando llego al límite de 10 reservas del plan gratis?',
    a: 'Cuando alcanzás las 10 reservas del mes, tus clientes no podrán hacer nuevas reservas hasta el mes siguiente o hasta que actualices al plan Pro. Tu cuenta no se bloquea ni perdés tu información.',
  },
  {
    q: '¿Puedo cancelar mi suscripción en cualquier momento?',
    a: 'Sí. Podés cancelar cuando quieras desde tu panel de configuración. No hay contratos ni penalidades. Tu cuenta pasa al plan Free automáticamente al finalizar el período pago.',
  },
  {
    q: '¿Mis datos y los de mis clientes están seguros?',
    a: 'Sí. Toda la información se almacena de forma segura y nunca compartimos tus datos con terceros. Los pagos en Paraguay son procesados por Bancard y Pagopar, que cumplen con los más altos estándares de seguridad del mercado local.',
  },
]

export default function Faq() {
  const [open, setOpen] = useState<number | null>(null)

  return (
    <section className="py-24 px-4 sm:px-6 bg-white border-t border-orange-border">
      <div className="max-w-3xl mx-auto">
        <FadeIn className="text-center mb-12">
          <span className="inline-block text-xs font-bold uppercase tracking-widest text-orange-primary mb-3">FAQ</span>
          <h2 className="text-3xl sm:text-4xl font-bold text-brand-text tracking-tight">
            Preguntas frecuentes
          </h2>
        </FadeIn>

        <FadeInStagger className="flex flex-col gap-3">
          {faqs.map((f, i) => (
            <motion.div
              key={i}
              variants={staggerItem}
              className={`rounded-2xl border transition-colors overflow-hidden ${
                open === i ? 'border-orange-primary bg-orange-lighter' : 'border-orange-border bg-white hover:border-orange-primary/50'
              }`}
            >
              <button
                onClick={() => setOpen(open === i ? null : i)}
                className="w-full flex items-center justify-between gap-4 px-6 py-4 text-left"
                aria-expanded={open === i}
                aria-controls={`faq-answer-${i}`}
              >
                <span className="font-semibold text-brand-text text-sm sm:text-base">{f.q}</span>
                <ChevronDown
                  className={`w-5 h-5 text-brand-sub flex-shrink-0 transition-transform duration-300 ${open === i ? 'rotate-180 text-orange-primary' : ''}`}
                  aria-hidden="true"
                />
              </button>
              <AnimatePresence initial={false}>
                {open === i && (
                  <motion.div
                    id={`faq-answer-${i}`}
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: 'auto', opacity: 1 }}
                    exit={{ height: 0, opacity: 0 }}
                    transition={{ duration: 0.3, ease: [0.22, 1, 0.36, 1] }}
                  >
                    <div className="px-6 pb-4">
                      <p className="text-sm text-brand-sub leading-relaxed">{f.a}</p>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ))}
        </FadeInStagger>
      </div>
    </section>
  )
}
