import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'

const inter = Inter({ subsets: ['latin'], variable: '--font-inter' })

export const metadata: Metadata = {
  title: 'Reservly Paraguay — Sistema de turnos online para tu negocio',
  description:
    'Reservly es el sistema de turnos online para peluquerías, psicólogos, nutricionistas y más en Paraguay. Gestioná tu agenda, recibí reservas 24/7 y automatizá confirmaciones. Gratis hasta 10 turnos/mes.',
  keywords: [
    'sistema de turnos online Paraguay','agenda online Paraguay','reservas online',
    'gestión de turnos','software de reservas Paraguay','turnos online Asunción',
    'reservar turno online','turno peluquería Paraguay',
  ],
  metadataBase: new URL('https://reservly.com.py'),
  openGraph: {
    title: 'Reservly Paraguay — Sistema de turnos online',
    description: 'Gestioná tu agenda online y recibí reservas 24/7 en Paraguay. Tus clientes eligen servicio, fecha y hora sin llamadas ni WhatsApp.',
    url: 'https://reservly.com.py',
    siteName: 'Reservly Paraguay',
    locale: 'es_PY',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Reservly Paraguay — Sistema de turnos online',
    description: 'Recibí reservas 24/7 sin llamadas ni WhatsApp. Para profesionales en Paraguay.',
  },
  robots: { index: true, follow: true },
  icons: {
    icon: "data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'><rect width='32' height='32' rx='8' fill='%23FF5C1F'/><path d='M8 10h16v2H8zm0 5h12v2H8zm0 5h10v2H8z' fill='white'/></svg>",
  },
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="es" className={inter.variable}>
      <head>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify({
              '@context': 'https://schema.org',
              '@type': 'SoftwareApplication',
              name: 'Reservly Paraguay',
              applicationCategory: 'BusinessApplication',
              operatingSystem: 'Web',
              offers: {
                '@type': 'Offer',
                price: '0',
                priceCurrency: 'PYG',
                description: 'Plan gratuito hasta 10 reservas/mes',
              },
              description: 'Sistema de turnos online para profesionales y negocios en Paraguay',
            }),
          }}
        />
      </head>
      <body>{children}</body>
    </html>
  )
}
