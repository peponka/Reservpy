import Navbar from '@/components/Navbar'
import Hero from '@/components/Hero'
import DashboardMockup from '@/components/DashboardMockup'
import Industries from '@/components/Industries'
import Stats from '@/components/Stats'
import Features from '@/components/Features'
import Reservbot from '@/components/Reservbot'
import SeoBlock from '@/components/SeoBlock'
import HowItWorks from '@/components/HowItWorks'
import Testimonials from '@/components/Testimonials'
import Pricing from '@/components/Pricing'
import Faq from '@/components/Faq'
import { FinalCta, Footer } from '@/components/FinalCtaAndFooter'

export default function Home() {
  return (
    <main>
      <Navbar />
      <Hero />
      <DashboardMockup />
      <Industries />
      <Stats />
      <Features />
      <Reservbot />
      <SeoBlock />
      <HowItWorks />
      <Testimonials />
      <Pricing />
      <Faq />
      <FinalCta />
      <Footer />
    </main>
  )
}
